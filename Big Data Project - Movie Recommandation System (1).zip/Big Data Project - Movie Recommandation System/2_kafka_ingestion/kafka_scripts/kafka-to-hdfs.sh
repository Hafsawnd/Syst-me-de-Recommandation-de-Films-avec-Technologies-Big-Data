#!/bin/bash

# Kafka binaries path
kafka_path="/usr/hdp/current/kafka-broker/bin"

# Zookeeper connect string
zookeeper_connect="sandbox.hortonworks.com:2181"

# Topics to consume from
topics=("dataset" "movietitles")

# HDFS target directory
hdfs_target_dir="/hiba_project/ingested-data"

# Timeout for the Kafka consumer (in milliseconds)
timeout_ms=5000

# Iterate through each topic
for topic in "${topics[@]}"; do
    # Consume messages from Kafka topic and write to a text file
    "${kafka_path}/kafka-console-consumer.sh" --zookeeper "${zookeeper_connect}" --topic "${topic}" --from-beginning --timeout-ms $timeout_ms > "${topic}_messages.txt"
    
    # Copy the text file to HDFS
    hdfs dfs -copyFromLocal "${topic}_messages.txt" "${hdfs_target_dir}/"
done

echo "Data has been successfully ingested into HDFS."