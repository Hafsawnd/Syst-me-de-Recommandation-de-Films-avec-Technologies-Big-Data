#!/bin/bash

# Kafka broker configuration
broker_list="sandbox.hortonworks.com:6667"
zookeeper_connect="localhost:2181"

# Path to the directory containing CSV files
csv_dir="/root/hiba_project/input_data"

# Path to Kafka binaries
kafka_path="/usr/hdp/current/kafka-broker/bin"

# Iterate through each CSV file in the directory
for file_path in "$csv_dir"/*.csv; do
    # Extract file name without extension
    file_name=$(basename "$file_path" .csv)
    
    # Use the file name as the Kafka topic
    topic="$file_name"
    
    # Set batch size based on file name
    if [ "$file_name" = "dataset" ]; then
        batch_size=5000
    elif [ "$file_name" = "moviestitles" ]; then
        batch_size=1000
    else
        batch_size=1000  # Default batch size
    fi
    
    # Create the Kafka topic if not exists
    "$kafka_path/kafka-topics.sh" --create --zookeeper "$zookeeper_connect" --replication-factor 1 --partitions 1 --topic "$topic" 2>/dev/null
    
    # Read CSV file and batch records
    batch=""
    line_count=0
    while IFS= read -r line; do
        batch="$batch$line\n"
        ((line_count++))
        
        # If batch size reached, send batch to Kafka
        if ((line_count >= batch_size)); then
            echo -e "$batch" | "$kafka_path/kafka-console-producer.sh" --broker-list "$broker_list" --topic "$topic" >/dev/null
            batch=""
            line_count=0
        fi
    done < "$file_path"
    
    # Send remaining records in the last batch
    if [ -n "$batch" ]; then
        echo -e "$batch" | "$kafka_path/kafka-console-producer.sh" --broker-list "$broker_list" --topic "$topic" >/dev/null
    fi

    # Print success message
    echo "Data from $file_name.csv has been successfully produced to the $topic Kafka topic."
done