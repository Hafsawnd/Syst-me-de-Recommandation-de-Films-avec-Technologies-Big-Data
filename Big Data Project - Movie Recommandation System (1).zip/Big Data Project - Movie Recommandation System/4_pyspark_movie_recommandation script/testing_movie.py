from pyspark import SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, col, lit, sqrt, mean

# Initialize SparkContext and HiveContext
sc = SparkContext.getOrCreate()
sqlContext = HiveContext(sc)

# Read the dataset
dataset_messages = sqlContext.read.text('/hiba_project/cleaned_data/part-v002-o000-r-00000')

# Split the lines into columns
dataset_messages = dataset_messages.select(split(dataset_messages.value, ',').alias('SplitValues'))
dataset_messages = dataset_messages.select(
    dataset_messages.SplitValues.getItem(0).alias('user_id'),
    dataset_messages.SplitValues.getItem(1).alias('item_id'),
    dataset_messages.SplitValues.getItem(2).alias('rating'),
    dataset_messages.SplitValues.getItem(3).alias('title'),
    dataset_messages.SplitValues.getItem(4).alias('timestamp')
)

# Convert columns to appropriate data types
dataset_messages = dataset_messages.withColumn('user_id', dataset_messages['user_id'].cast('int'))
dataset_messages = dataset_messages.withColumn('item_id', dataset_messages['item_id'].cast('int'))
dataset_messages = dataset_messages.withColumn('rating', dataset_messages['rating'].cast('float'))
dataset_messages = dataset_messages.withColumn('timestamp', dataset_messages['timestamp'].cast('int'))

# Split data into training and test sets
(training_data, test_data) = dataset_messages.randomSplit([0.8, 0.2], seed=12345)

# Calculate user similarity using only training data
user_item_ratings = training_data.rdd.map(lambda row: (row.user_id, (row.item_id, row.rating)))
user_item_grouped = user_item_ratings.groupByKey().mapValues(list)

# Define cosine similarity function
def cosine_similarity(user1, user2):
    ratings1 = {item: rating for item, rating in user1}
    ratings2 = {item: rating for item, rating in user2}
    common_items = set(ratings1.keys()).intersection(ratings2.keys())
    
    if len(common_items) == 0:
        return 0.0
        
    sum1 = sum([ratings1[item] ** 2 for item in common_items])
    sum2 = sum([ratings2[item] ** 2 for item in common_items])
    
    sum12 = sum([ratings1[item] * ratings2[item] for item in common_items])
    if sum1 == 0 or sum2 == 0:
        return 0.0
        
    return sum12 / (sum1 ** 0.5 * sum2 ** 0.5)

# Compute similarity between users
user_similarities = user_item_grouped.cartesian(user_item_grouped) \
    .filter(lambda x: x[0][0] != x[1][0]) \
    .map(lambda x: ((x[0][0], x[1][0]), cosine_similarity(x[0][1], x[1][1])))

# Get top N similar users for each user
top_n_similar_users = user_similarities.map(lambda x: (x[0][0], (x[0][1], x[1]))) \
    .groupByKey().mapValues(lambda x: sorted(list(x), key=lambda y: -y[1])[:10])

# Function to recommend items
def recommend_items(user, similar_users, user_item_ratings):
    user_items = {item: rating for item, rating in user_item_ratings[user]}
    recommendations = {}
    for similar_user, similarity in similar_users:
        for item, rating in user_item_ratings[similar_user]:
            if item not in user_items:
                if item not in recommendations:
                    recommendations[item] = (0.0, 0.0)
                score, similarity_sum = recommendations[item]
                recommendations[item] = (score + rating * similarity, similarity_sum + similarity)
    recommended_items = [(item, score / similarity) for item, (score, similarity) in recommendations.items() if similarity > 0]
    return sorted(recommended_items, key=lambda x: -x[1])[:10]

# Generate recommendations for the test users
user_item_dict = user_item_grouped.collectAsMap()
test_user_ids = test_data.select('user_id').distinct().rdd.map(lambda r: r[0]).collect()
test_user_recommendations = top_n_similar_users.filter(lambda x: x[0] in test_user_ids) \
    .map(lambda x: (x[0], recommend_items(x[0], x[1], user_item_dict)))

# Convert to DataFrame
test_user_recommendations_rows = test_user_recommendations.flatMap(lambda x: [(x[0], rec[0], rec[1]) for rec in x[1]])
test_user_recommendations_df = sqlContext.createDataFrame(test_user_recommendations_rows, ["user_id", "item_id", "predicted_rating"])

# Function to calculate precision and recall
def calculate_precision_recall(recommendations, test_data, n):
    test_data_true = test_data.select('user_id', 'item_id').withColumn('actual', lit(1))
    true_positives = recommendations.join(test_data_true, on=['user_id', 'item_id'], how='inner') \
        .groupBy('user_id').count().withColumnRenamed("count", "tp")
    total_recommendations = recommendations.groupBy('user_id').count().withColumnRenamed("count", "total_recommendations")
    total_relevant = test_data_true.groupBy('user_id').count().withColumnRenamed("count", "total_relevant")
    metrics = true_positives.join(total_recommendations, on='user_id', how='left') \
        .join(total_relevant, on='user_id', how='left') \
        .withColumn('precision', col('tp') / col('total_recommendations')) \
        .withColumn('recall', col('tp') / col('total_relevant'))
    metrics.select('user_id', 'precision', 'recall').show()
    return metrics

# Calculate precision and recall
metrics = calculate_precision_recall(test_user_recommendations_df, test_data, 10)

# Function to calculate RMSE
def calculate_rmse(recommendations, test_data):
    joined_data = recommendations.join(test_data, on=['user_id', 'item_id'], how='inner')
    differences = joined_data.withColumn('squared_difference', (joined_data.predicted_rating - joined_data.rating) ** 2)
    rmse = differences.agg(sqrt(mean('squared_difference')).alias('rmse')).collect()[0]['rmse']
    print(f'RMSE: {rmse}')
    return rmse

# Calculate RMSE
rmse = calculate_rmse(test_user_recommendations_df, test_data)

# Display metrics
print("Evaluation Metrics:")
metrics.select('user_id', 'precision', 'recall').show()
print(f'RMSE: {rmse}')
