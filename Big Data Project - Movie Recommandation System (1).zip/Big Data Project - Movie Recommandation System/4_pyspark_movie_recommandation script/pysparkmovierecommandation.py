from pyspark import SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import split, col

# Get existing SparkContext
sc = SparkContext.getOrCreate()

# Initialize HiveContext
sqlContext = HiveContext(sc)

# Read the datasets
dataset_messages = sqlContext.read.text('/hiba_project/cleaned_data/part-v002-o000-r-00000')

# Split the lines into columns
dataset_messages = dataset_messages.select(split(dataset_messages.value, ',').alias('SplitValues'))
dataset_messages = dataset_messages.select(
    dataset_messages.SplitValues.getItem(0).alias('user_id'),
    dataset_messages.SplitValues.getItem(1).alias('item_id'),
    dataset_messages.SplitValues.getItem(2).alias('rating'),
    dataset_messages.SplitValues.getItem(3).alias('title'),
    dataset_messages.SplitValues.getItem(4).alias('timestamp')
)

# Convert columns to appropriate data types
dataset_messages = dataset_messages.withColumn('user_id', dataset_messages['user_id'].cast('int'))
dataset_messages = dataset_messages.withColumn('item_id', dataset_messages['item_id'].cast('int'))
dataset_messages = dataset_messages.withColumn('rating', dataset_messages['rating'].cast('float'))
dataset_messages = dataset_messages.withColumn('timestamp', dataset_messages['timestamp'].cast('int'))

# Show a sample of the data
dataset_messages.show(5)

# Calculate user similarity
user_item_ratings = dataset_messages.rdd.map(lambda row: (row.user_id, (row.item_id, row.rating)))

# Group by user_id
user_item_grouped = user_item_ratings.groupByKey().mapValues(list)

# Calculate cosine similarity
def cosine_similarity(user1, user2):
    ratings1 = {item: rating for item, rating in user1}
    ratings2 = {item: rating for item, rating in user2}
    common_items = set(ratings1.keys()).intersection(ratings2.keys())
    
    if len(common_items) == 0:
        return 0.0
    
    sum1 = sum([ratings1[item] ** 2 for item in common_items])
    sum2 = sum([ratings2[item] ** 2 for item in common_items])
    sum12 = sum([ratings1[item] * ratings2[item] for item in common_items])
    
    if sum1 == 0 or sum2 == 0:
        return 0.0
    
    return sum12 / (sum1 ** 0.5 * sum2 ** 0.5)

# Compute similarity between users
user_similarities = user_item_grouped.cartesian(user_item_grouped) \
    .filter(lambda x: x[0][0] != x[1][0]) \
    .map(lambda x: ((x[0][0], x[1][0]), cosine_similarity(x[0][1], x[1][1])))

# Get top N similar users for each user
top_n_similar_users = user_similarities.map(lambda x: (x[0][0], (x[0][1], x[1]))) \
    .groupByKey().mapValues(lambda x: sorted(list(x), key=lambda y: -y[1])[:10])

# Recommend items
def recommend_items(user, similar_users, user_item_ratings):
    user_items = {item: rating for item, rating in user_item_ratings[user]}
    recommendations = {}
    
    for similar_user, similarity in similar_users:
        for item, rating in user_item_ratings[similar_user]:
            if item not in user_items:
                if item not in recommendations:
                    recommendations[item] = (0.0, 0.0)
                score, similarity_sum = recommendations[item]
                recommendations[item] = (score + rating * similarity, similarity_sum + similarity)
    
    recommended_items = [(item, score / similarity) for item, (score, similarity) in recommendations.items() if similarity > 0]
    recommended_items = sorted(recommended_items, key=lambda x: -x[1])[:10]
    return recommended_items

# Generate recommendations
user_item_dict = user_item_grouped.collectAsMap()
user_recommendations = top_n_similar_users.map(lambda x: (x[0], recommend_items(x[0], x[1], user_item_dict)))

# Convert to DataFrame for visualization
user_recommendations_rows = user_recommendations.flatMap(lambda x: [(x[0], rec[0], rec[1]) for rec in x[1]])
user_recommendations_df = sqlContext.createDataFrame(user_recommendations_rows, ["user_id", "item_id", "rating"])

# Remove duplicates (user_id, item_id) to ensure one user does not have the same movie twice
user_recommendations_df = user_recommendations_df.dropDuplicates(["user_id", "item_id"])

# Join with original dataset to get movie titles
# Alias the dataset_messages to avoid ambiguity
dataset_messages_alias = dataset_messages.select(col("item_id").alias("item_id"), col("title").alias("title"))

# Join user_recommendations_df with dataset_messages_alias
user_recommendations_with_titles = user_recommendations_df.join(dataset_messages_alias, on='item_id', how='inner')

# Select the required columns
user_recommendations_with_titles = user_recommendations_with_titles.select("user_id", "item_id", "rating", "title")

# Show top recommendations
user_recommendations_with_titles.show(10)

# Save the recommendations to a Hive table
user_recommendations_with_titles.write.format("parquet").mode("overwrite").saveAsTable("hiba_project.movie_recommendations")
